let body = $response.body
body=JSON.parse(body)
body['data']['relates'].forEach((element, index)=> {
   if(element.hasOwnProperty('is_ad')){      
      body['data']['relates'].splice(index,1)  
    }
});
delete body['data']['cms']
body=JSON.stringify(body)
$done({body})
